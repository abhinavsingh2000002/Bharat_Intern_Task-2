find manage_fastapi/. -type f -name "*.py" | xargs mypy
