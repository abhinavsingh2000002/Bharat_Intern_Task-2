# {{ cookiecutter.name }}

This project was generated via [manage-fastapi](https://github.com/ycd/manage-fastapi)! :tada:

## License

This project is licensed under the terms of the {{ cookiecutter.license }} license.
